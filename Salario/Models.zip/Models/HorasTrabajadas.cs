﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Salario.Models
{
    public class HorasTrabajadas
    {

        public int Fecha { get; set; }
        public DateTime HoraEntrada { get; set; }
        public DateTime HoraSalida { get; set; }

    }
}